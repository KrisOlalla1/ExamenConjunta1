class MiTabla extends HTMLElement {
    constructor() {
        super();
        console.log('Componente <mi-tabla> inicializado');
        this.attachShadow({ mode: 'open' });
        this.table = document.createElement('table');
        this.table.classList.add('table');
        this.table.innerHTML = `
            <thead>
                <tr>
                    <!-- Cabeceras dinámicas se agregan aquí -->
                </tr>
            </thead>
            <tbody></tbody>
        `;
        this.shadowRoot.appendChild(this.table);

        // Estilos CSS
        const styles = document.createElement('style');
        styles.textContent = `
            .table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }
            .table th, .table td {
                padding: 10px;
                text-align: left;
                border: 1px solid #ddd;
            }
            .table th {
                background-color: #f4f4f4;
            }
        `;
        this.shadowRoot.appendChild(styles);
    }

    // Método para obtener y renderizar datos
    async connectedCallback() {
        const apiEndpoint = this.getAttribute('src'); // Asegúrate de usar 'src' en lugar de 'api-endpoint'
        if (!apiEndpoint) {
            console.error('Error: No se especificó el atributo "src".');
            return;
        }
        await this.loadData(apiEndpoint);
    }

    // Método para cargar los datos desde la API
    async loadData(apiEndpoint) {
        try {
            const response = await fetch(apiEndpoint);
            const data = await response.json();
            const tbody = this.table.querySelector('tbody');
            const thead = this.table.querySelector('thead tr');

            // Limpiar cualquier dato previo
            tbody.innerHTML = '';
            thead.innerHTML = '';

            // Generar las cabeceras de la tabla dinámicamente
            const headers = Object.keys(data[0]);
            headers.forEach(header => {
                const th = document.createElement('th');
                th.textContent = header;
                thead.appendChild(th);
            });

            // Añadir filas a la tabla
            data.forEach(item => {
                const row = document.createElement('tr');
                headers.forEach(header => {
                    const td = document.createElement('td');
                    td.textContent = item[header];
                    row.appendChild(td);
                });
                tbody.appendChild(row);
            });
        } catch (error) {
            console.error('Error al cargar los datos de la API:', error);
        }
    }
}

// Definir el custom element
customElements.define('mi-tabla', MiTabla);
