class StudentCrud extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({mode: 'open'});
    }

    connectedCallback() {
        this.render();
        this.addEventListeners();
        this.fetchStudents();
    }

    render() {
        this.shadowRoot.innerHTML = `
            <style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    padding: 8px;
                    border: 1px solid #ddd;
                    text-align: left;
                }
                button {
                    padding: 5px 10px;
                    background-color: #3498db;
                    color: white;
                    border: none;
                    cursor: pointer;
                }
            </style>
            <h3>Estudiantes</h3>
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Grado</th>
                        <th>Correo</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="student-list"></tbody>
            </table>
            <h3>Agregar Estudiante</h3>
            <form id="student-form">
                <label>Nombre: <input type="text" id="nombre" required /></label>
                <label>Grado: <input type="text" id="grado" required /></label>
                <label>Correo: <input type="email" id="correo" required /></label>
                <button type="submit">Agregar Estudiante</button>
            </form>
        `;
    }

    addEventListeners() {
        const form = this.shadowRoot.getElementById('student-form');
        form.addEventListener('submit', (event) => {
            event.preventDefault();
            this.createStudent();
        });
    }

    async fetchStudents() {
        const response = await fetch('http://localhost:8000/estudiantes');
        const students = await response.json();
        this.renderStudentList(students);
    }

    renderStudentList(students) {
        const studentList = this.shadowRoot.getElementById('student-list');
        studentList.innerHTML = students.map(student => `
            <tr>
                <td>${student.nombre}</td>
                <td>${student.grado}</td>
                <td>${student.correo}</td>
                <td>
                    <button class="edit-btn" data-id="${student.id_estudiante}">Editar</button>
                    <button class="delete-btn" data-id="${student.id_estudiante}">Eliminar</button>
                </td>
            </tr>
        `).join('');

        this.addCrudEventListeners();
    }

    addCrudEventListeners() {
        const deleteButtons = this.shadowRoot.querySelectorAll('.delete-btn');
        deleteButtons.forEach(button => {
            button.addEventListener('click', () => this.deleteStudent(button.dataset.id));
        });

        const editButtons = this.shadowRoot.querySelectorAll('.edit-btn');
        editButtons.forEach(button => {
            button.addEventListener('click', () => this.editStudent(button.dataset.id));
        });
    }

    async createStudent() {
        const studentData = {
            nombre: this.shadowRoot.getElementById('nombre').value,
            grado: this.shadowRoot.getElementById('grado').value,
            correo: this.shadowRoot.getElementById('correo').value,
        };
        await fetch('http://localhost:8000/estudiantes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(studentData)
        });
        this.fetchStudents();
    }

    async deleteStudent(id) {
        await fetch(`http://localhost:8000/estudiantes/${id}`, { method: 'DELETE' });
        this.fetchStudents();
    }

    async editStudent(id) {
        // Obtener los datos actuales del estudiante
        const response = await fetch(`http://localhost:8000/estudiantes/${id}`);
        const student = await response.json();
    
        // Llenar el formulario con los datos existentes
        this.shadowRoot.getElementById('nombre').value = student.nombre;
        this.shadowRoot.getElementById('grado').value = student.grado;
        this.shadowRoot.getElementById('correo').value = student.correo;
    
        // Cambiar el texto del botón y preparar para actualizar
        const form = this.shadowRoot.getElementById('student-form');
        const submitButton = form.querySelector('button[type="submit"]');
        submitButton.textContent = "Actualizar Estudiante";
    
        // Eliminar cualquier listener anterior que se haya asignado
        form.removeEventListener('submit', this.createStudent);
    
        // Agregar un nuevo listener para actualizar el estudiante
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
    
            // Recoger los valores actualizados
            const updatedStudent = {
                nombre: this.shadowRoot.getElementById('nombre').value,
                grado: this.shadowRoot.getElementById('grado').value,
                correo: this.shadowRoot.getElementById('correo').value,
            };
    
            // Enviar los datos actualizados al servidor
            await fetch(`http://localhost:8000/estudiantes/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatedStudent),
            });
    
            // Resetear el formulario y el botón
            form.reset();
            submitButton.textContent = "Agregar Estudiante"; // Volver al texto original
            form.removeEventListener('submit', arguments.callee); // Limpiar el listener actual
    
            // Volver a asignar el listener original para crear estudiantes
            form.addEventListener('submit', (event) => {
                event.preventDefault();
                this.createStudent();
            });
    
            // Refrescar la lista de estudiantes
            this.fetchStudents();
        }, { once: true }); // Usar once: true para que se ejecute solo una vez
    }
    
    
}

customElements.define('student-crud', StudentCrud);
