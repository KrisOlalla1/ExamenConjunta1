class ClubCrud extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({mode: 'open'});
    }

    connectedCallback() {
        this.render();
        this.addEventListeners();
        this.fetchClubs();
    }

    render() {
        this.shadowRoot.innerHTML = `
            <style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    padding: 8px;
                    border: 1px solid #ddd;
                    text-align: left;
                }
                button {
                    padding: 5px 10px;
                    background-color: #3498db;
                    color: white;
                    border: none;
                    cursor: pointer;
                }
            </style>
            <h3>Clubs</h3>
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Actividad Principal</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="club-list"></tbody>
            </table>
            <h3>Agregar Club</h3>
            <form id="club-form">
                <label>Nombre: <input type="text" id="nombre" required /></label>
                <label>Actividad Principal: <input type="text" id="actividad" required /></label>
                <button type="submit">Agregar Club</button>
            </form>
        `;
    }

    addEventListeners() {
        const form = this.shadowRoot.getElementById('club-form');
        form.addEventListener('submit', (event) => {
            event.preventDefault();
            this.createClub();
        });
    }

    async fetchClubs() {
        const response = await fetch('http://localhost:8000/clubs');
        const clubs = await response.json();
        this.renderClubList(clubs);
    }

    renderClubList(clubs) {
        const clubList = this.shadowRoot.getElementById('club-list');
        clubList.innerHTML = clubs.map(club => `
            <tr>
                <td>${club.nombre}</td>
                <td>${club.actividad_principal}</td>
                <td>
                    <button class="edit-btn" data-id="${club.id_club}">Editar</button>
                    <button class="delete-btn" data-id="${club.id_club}">Eliminar</button>
                </td>
            </tr>
        `).join('');

        this.addCrudEventListeners();
    }

    addCrudEventListeners() {
        const deleteButtons = this.shadowRoot.querySelectorAll('.delete-btn');
        deleteButtons.forEach(button => {
            button.addEventListener('click', () => this.deleteClub(button.dataset.id));
        });

        const editButtons = this.shadowRoot.querySelectorAll('.edit-btn');
        editButtons.forEach(button => {
            button.addEventListener('click', () => this.editClub(button.dataset.id));
        });
    }

    async createClub() {
        const clubData = {
            nombre: this.shadowRoot.getElementById('nombre').value,
            actividad_principal: this.shadowRoot.getElementById('actividad').value,
        };
        await fetch('http://localhost:8000/clubs', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(clubData)
        });
        this.fetchClubs();
    }

    async deleteClub(id) {
        await fetch(`http://localhost:8000/clubs/${id}`, { method: 'DELETE' });
        this.fetchClubs();
    }

    async editClub(id) {
        // Obtener los datos actuales del club
        const response = await fetch(`http://localhost:8000/clubs/${id}`);
        const club = await response.json();
    
        // Llenar el formulario con los datos existentes
        this.shadowRoot.getElementById('nombre').value = club.nombre;
        this.shadowRoot.getElementById('actividad').value = club.actividad_principal;
    
        // Cambiar el texto del botón y preparar para actualizar
        const form = this.shadowRoot.getElementById('club-form');
        const submitButton = form.querySelector('button[type="submit"]');
        submitButton.textContent = "Actualizar Club";
    
        // Limpiar cualquier listener anterior
        form.removeEventListener('submit', this.createClub);
    
        // Listener para actualizar el club
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
    
            // Recoger los valores actualizados
            const updatedClub = {
                nombre: this.shadowRoot.getElementById('nombre').value,
                actividad_principal: this.shadowRoot.getElementById('actividad').value,
            };
    
            // Enviar los datos actualizados al servidor
            await fetch(`http://localhost:8000/clubs/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatedClub),
            });
    
            // Resetear el formulario y el botón
            form.reset();
            submitButton.textContent = "Agregar Club"; // Volver al texto original
            form.removeEventListener('submit', arguments.callee); // Limpiar el listener actual
    
            // Volver a asignar el listener original para crear clubs
            form.addEventListener('submit', (event) => {
                event.preventDefault();
                this.createClub();
            });
    
            // Refrescar la lista de clubs
            this.fetchClubs();
        }, { once: true }); // Usar once: true para que se ejecute solo una vez
    }
    
    
}

customElements.define('club-crud', ClubCrud);
