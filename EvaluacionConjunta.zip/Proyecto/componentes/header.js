class HeaderComponent extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({mode: 'open'});
    }

    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                header {
                    background-color: #2c3e50;
                    color: white;
                    padding: 15px;
                    text-align: center;
                }
            </style>
            <header>
                <h1>Sistema Escolar</h1>
            </header>
        `;
    }
}

customElements.define('header-component', HeaderComponent);
