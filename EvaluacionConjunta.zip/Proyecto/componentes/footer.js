class FooterComponent extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({mode: 'open'});
    }

    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                footer {
                    background-color: #333;
                    color: white;
                    padding: 10px;
                    text-align: center;
                }
            </style>
            <footer>
                <p>&copy; 2024 Sistema Escolar</p>
            </footer>
        `;
    }
}

customElements.define('footer-component', FooterComponent);
