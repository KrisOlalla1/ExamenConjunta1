import express from 'express';
import bodyParser from 'body-parser';
import mysql from 'mysql2';
import cors from 'cors';

const app = express();
const port = 8000;

app.use(cors());
app.use(bodyParser.json());

// Conexión a la base de datos
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3306,
    database: 'sistema_escolar'
});

db.connect((error) => {
    if (error) {
        console.log("Error al conectar a la base de datos");
        return;
    }
    console.log("Conexión exitosa");
});
// Ruta para obtener un estudiante por su ID
app.get('/estudiantes/:id', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM Estudiantes WHERE id_estudiante = ?';
    db.query(query, [id], (error, results) => {
        if (error) {
            return res.status(500).send('Error al ejecutar la consulta');
        }
        if (results.length === 0) {
            return res.status(404).send('Estudiante no encontrado');
        }
        res.status(200).json(results[0]); // Devolver el estudiante encontrado
    });
});

// Resto de la API permanece igual

// CRUD Estudiantes
app.get("/estudiantes", (req, res) => {
    const query = "SELECT * FROM Estudiantes";
    db.query(query, (error, results) => {
        if (error) {
            res.status(500).send('Error al ejecutar la consulta');
            return;
        } else {
            res.status(200).json(results);
        }
    });
});

app.post("/estudiantes", (req, res) => {
    const { nombre, grado, correo } = req.body;
    const query = 'INSERT INTO Estudiantes (nombre, grado, correo) VALUES (?, ?, ?)';
    db.query(query, [nombre, grado, correo], (error, results) => {
        if (error) {
            res.status(500).send('Error al ejecutar la consulta');
            return;
        } else {
            res.status(201).json('Estudiante registrado exitosamente');
        }
    });
});

app.put('/estudiantes/:id', (req, res) => {
    const { id } = req.params;
    const { nombre, grado, correo } = req.body;
    const query = 'UPDATE Estudiantes SET nombre=?, grado=?, correo=? WHERE id_estudiante=?';
    db.query(query, [nombre, grado, correo, id], (error, results) => {
        if (error) {
            res.status(500).send('Error al actualizar el estudiante');
            return;
        }
        res.status(200).json('Estudiante actualizado exitosamente');
    });
});

app.delete('/estudiantes/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM Estudiantes WHERE id_estudiante=?';
    db.query(query, [id], (error, results) => {
        if (error) {
            res.status(500).send('Error al eliminar el estudiante');
            return;
        }
        res.status(200).json('Estudiante eliminado exitosamente');
    });
});
// Ruta para obtener un club por su ID
app.get('/clubs/:id', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM Clubs WHERE id_club = ?';
    db.query(query, [id], (error, results) => {
        if (error) {
            return res.status(500).send('Error al ejecutar la consulta');
        }
        if (results.length === 0) {
            return res.status(404).send('Club no encontrado');
        }
        res.status(200).json(results[0]); // Devolver el club encontrado
    });
});

// CRUD Clubs
app.get("/clubs", (req, res) => {
    const query = "SELECT * FROM Clubs";
    db.query(query, (error, results) => {
        if (error) {
            res.status(500).send('Error al ejecutar la consulta');
            return;
        } else {
            res.status(200).json(results);
        }
    });
});

app.post("/clubs", (req, res) => {
    const { nombre, actividad_principal } = req.body;
    const query = 'INSERT INTO Clubs (nombre, actividad_principal) VALUES (?, ?)';
    db.query(query, [nombre, actividad_principal], (error, results) => {
        if (error) {
            res.status(500).send('Error al ejecutar la consulta');
            return;
        } else {
            res.status(201).json('Club registrado exitosamente');
        }
    });
});

app.put('/clubs/:id', (req, res) => {
    const { id } = req.params;
    const { nombre, actividad_principal } = req.body;
    const query = 'UPDATE Clubs SET nombre=?, actividad_principal=? WHERE id_club=?';
    db.query(query, [nombre, actividad_principal, id], (error, results) => {
        if (error) {
            res.status(500).send('Error al actualizar el club');
            return;
        }
        res.status(200).json('Club actualizado exitosamente');
    });
});

app.delete('/clubs/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM Clubs WHERE id_club=?';
    db.query(query, [id], (error, results) => {
        if (error) {
            res.status(500).send('Error al eliminar el club');
            return;
        }
        res.status(200).json('Club eliminado exitosamente');
    });
});

// Ruta para obtener miembros de clubs
app.get('/miembros', (req, res) => {
    const query = `
        SELECT e.nombre AS nombre_estudiante, c.nombre AS nombre_club
        FROM MiembrosClub mc
        JOIN Estudiantes e ON mc.id_estudiante = e.id_estudiante
        JOIN Clubs c ON mc.id_club = c.id_club
    `;
    db.query(query, (error, results) => {
        if (error) {
            res.status(500).send('Error al ejecutar la consulta');
            return;
        }
        res.status(200).json(results);
    });
});
// Servir la API
app.listen(port, () => {
    console.log(`Servidor escuchando en el puerto ${port}`);
});
